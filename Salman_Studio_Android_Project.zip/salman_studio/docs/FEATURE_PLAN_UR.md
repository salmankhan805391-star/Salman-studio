# سلمان اسٹوڈیو — مکمل فیچر پلان

## موبائل ایپ
- Home dashboard اور Salman Studio branding
- Character library: 50 male, 50 female, 50 baby-style starter profiles
- Custom character: gallery photo import, name, saved local profile
- Character identity profile: reference images, outfit notes, voice selection metadata
- Create modes: text-to-video, image-to-video, story-to-movie, movie-to-cartoon, voice/dialogue
- Projects: draft saving, project history, resumable workflow metadata
- Editor plan: scene order, trim points, captions, audio tracks, transitions
- Export plan: MP4, image, audio; Android MediaStore/Downloads integration still required
- Settings: local device authentication option and private-device policy

## AI processing pipeline (requires real provider integrations)
1. Upload the user's authorized source media to private storage.
2. Analyze video into scenes and shot boundaries.
3. Extract a scene/character description and user-approved identity references.
4. Generate stylized frames or clips using an image/video provider.
5. Generate permitted dialogue/voice and align lip-sync.
6. Assemble clips, audio, captions and transitions into a final MP4.
7. Return a download URL or save to Android Downloads through the app.

## Required before production
- Choose video, image, speech and optional lip-sync providers.
- Obtain API credentials from those providers and configure them only on the backend.
- Implement provider adapters, task queue, progress events, retries, billing limits and cancellation.
- Use private object storage, encryption, retention/deletion controls and user consent.
- Implement real device registration and revocation. A shared secret in a starter app is not sufficient for production device security.
- Add copyright/permission checks and consent for voice likeness and uploaded people's images.
- Test with short clips first; full-length movie conversion is expensive and may take a long time.

## Current package status
This repository is a functional UI/project starter and a backend API scaffold. It does not yet generate actual AI media. The API deliberately reports `awaiting_provider_configuration` rather than pretending that a video has been generated.
