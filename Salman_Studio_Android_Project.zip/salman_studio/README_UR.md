# سلمان اسٹوڈیو — Android پروجیکٹ

یہ Salman Studio کا Flutter Android starter package ہے۔ اس میں برانڈڈ UI، پانچ مین سیکشن، 150 starter character slots، custom photo character entry، create modes، local project saving، device authentication option اور APK build workflow شامل ہیں۔

## ZIP میں کیا ہے؟
- `lib/main.dart`: Android app source
- `pubspec.yaml`: Flutter dependencies
- `.github/workflows/build-apk.yml`: GitHub Actions سے APK build
- `backend/`: FastAPI backend scaffold
- `docs/FEATURE_PLAN_UR.md`: مکمل فیچر اور production roadmap

## ابھی کیا کام کرتا ہے؟
- ایپ کا UI اور navigation
- 50 Male، 50 Female، 50 Baby-style starter character cards
- گیلری سے تصویر منتخب کرکے custom character entry بنانا (اس موجودہ سیشن میں memory-only)
- image/movie picker اور creation prompt
- project prompt اور metadata فون پر محفوظ کرنا
- settings میں device authentication کی آزمائش
- GitHub Actions workflow سے Android APK build کرنے کی کوشش

## ابھی کیا کام نہیں کرتا؟
حقیقی AI video generation، full movie-to-cartoon، voice cloning/synthesis، lip-sync، auto subtitles، video editor rendering، اور Android Downloads میں generated media export ابھی منسلک نہیں۔ ان کے لیے منتخب AI providers، backend credentials، processing workers، cloud storage اور مزید app integration درکار ہے۔

## APK بنانے کا راستہ
1. GitHub پر repository بنائیں اور ZIP extract کرکے تمام فائلیں upload/commit کریں۔
2. GitHub کے Actions میں `Build Salman Studio Android APK` چلائیں۔
3. workflow کامیاب ہو تو `salman-studio-release-apk` artifact ڈاؤن لوڈ کریں۔

اگر workflow میں build error آئے تو error کا screenshot بھیجیں؛ Flutter SDK یا Android build settings کے مطابق اسے درست کرنا ہوگا۔

## رازداری اور device lock
Local biometric prompt اس فون کی سہولت استعمال کرتا ہے، مگر یہ APK کو دوسرے فون پر install ہونے سے نہیں روکتا۔ حقیقی one-device-only access کے لیے backend device registration، revocation، signed tokens اور secure storage لازمی ہیں۔ Provider API keys کبھی APK میں شامل نہ کریں۔

## AI سروسز اور اخراجات
ہر provider کی قیمت، supported duration، resolution، queue اور usage policy مختلف ہوتی ہے۔ لمبی فلمیں scene-by-scene بنیں گی؛ لامحدود مفت generation کی ضمانت نہیں دی جا سکتی۔ صرف وہ تصاویر، ویڈیوز اور آوازیں استعمال کریں جن کے استعمال کی اجازت آپ کے پاس ہو۔
