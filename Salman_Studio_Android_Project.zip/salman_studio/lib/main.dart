import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const SalmanStudioApp());

const Color ink = Color(0xFF090D1C);
const Color panel = Color(0xFF151C33);
const Color gold = Color(0xFFFFC857);
const Color cyan = Color(0xFF55D6FF);

class SalmanStudioApp extends StatelessWidget {
  const SalmanStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Salman Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold,
          brightness: Brightness.dark,
          surface: panel,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: ink,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          color: panel,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: Colors.white.withOpacity(.07)),
          ),
        ),
      ),
      home: const StudioShell(),
    );
  }
}

class StudioShell extends StatefulWidget {
  const StudioShell({super.key});

  @override
  State<StudioShell> createState() => _StudioShellState();
}

class _StudioShellState extends State<StudioShell> {
  int index = 0;
  final pages = const [
    HomePage(),
    CharactersPage(),
    CreatePage(),
    ProjectsPage(),
    SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF11172A),
        indicatorColor: gold.withOpacity(.18),
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.face_retouching_natural), label: 'Characters'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Create'),
          NavigationDestination(icon: Icon(Icons.folder_copy), label: 'Projects'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class BrandMark extends StatelessWidget {
  final double size;
  const BrandMark({super.key, this.size = 58});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * .28),
        gradient: const LinearGradient(
          colors: [Color(0xFFFFE29A), Color(0xFFFFB52E), Color(0xFFDA7B16)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(color: gold.withOpacity(.22), blurRadius: 20, spreadRadius: 1),
        ],
      ),
      child: Icon(Icons.movie_creation_rounded, color: ink, size: size * .57),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        Row(
          children: [
            const BrandMark(),
            const SizedBox(width: 13),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SALMAN STUDIO',
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
                  Text('Your personal AI film studio',
                      style: TextStyle(color: Colors.white60, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.shield_rounded, color: cyan),
          ],
        ),
        const SizedBox(height: 25),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            gradient: const LinearGradient(
              colors: [Color(0xFF263B70), Color(0xFF171D39), Color(0xFF35224F)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('TURN YOUR IDEAS INTO MOVIES',
                  style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1)),
              const SizedBox(height: 10),
              const Text('Create characters. Give them voices. Make your own cartoon world.',
                  style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, height: 1.2)),
              const SizedBox(height: 18),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: gold,
                  foregroundColor: ink,
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                ),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const CreatePage()),
                ),
                icon: const Icon(Icons.auto_awesome),
                label: const Text('Start creating'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const SectionTitle('Creative studio'),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.22,
          children: const [
            FeatureTile(icon: Icons.movie_filter, title: 'Movie to Cartoon', subtitle: 'Transform a movie'),
            FeatureTile(icon: Icons.text_fields, title: 'Text to Video', subtitle: 'Turn a prompt into scenes'),
            FeatureTile(icon: Icons.image, title: 'Image to Video', subtitle: 'Animate a picture'),
            FeatureTile(icon: Icons.mic, title: 'Voice Studio', subtitle: 'Create character dialogue'),
            FeatureTile(icon: Icons.face, title: 'Character Creator', subtitle: 'Build your own cast'),
            FeatureTile(icon: Icons.edit_video, title: 'Video Editor', subtitle: 'Arrange your scenes'),
          ],
        ),
        const SizedBox(height: 20),
        const SectionTitle('Your studio includes'),
        const SizedBox(height: 10),
        const InfoLine(icon: Icons.people_alt, text: '150 starter character profiles: 50 male, 50 female, 50 baby-style'),
        const InfoLine(icon: Icons.lock, text: 'Private-device sign-in options'),
        const InfoLine(icon: Icons.download, text: 'Save generated files to your Android device'),
        const InfoLine(icon: Icons.subtitles, text: 'Plan for Urdu, Punjabi and English dialogue'),
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(text,
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800));
}

class FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const FeatureTile({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: panel,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: gold, size: 28),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ],
      ),
    );
  }
}

class InfoLine extends StatelessWidget {
  final IconData icon;
  final String text;
  const InfoLine({super.key, required this.icon, required this.text});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [
      Icon(icon, color: cyan, size: 19),
      const SizedBox(width: 10),
      Expanded(child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 13))),
    ]),
  );
}

class CharactersPage extends StatefulWidget {
  const CharactersPage({super.key});
  @override
  State<CharactersPage> createState() => _CharactersPageState();
}

class _CharactersPageState extends State<CharactersPage> {
  String category = 'Male';
  final List<Map<String, String>> custom = [];

  List<Map<String, String>> get starter {
    final prefixes = category == 'Male'
        ? ['Hero', 'Adventurer', 'Friend', 'King', 'Explorer']
        : category == 'Female'
            ? ['Artist', 'Princess', 'Scientist', 'Friend', 'Explorer']
            : ['Little Star', 'Tiny Hero', 'Baby', 'Little Friend', 'Dreamer'];
    return List.generate(50, (i) => {
      'name': '${prefixes[i % prefixes.length]} ${i + 1}',
      'type': category,
      'number': '${i + 1}',
    });
  }

  Future<void> addCharacter() async {
    final image = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (image == null) return;
    if (!mounted) return;
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) {
        final controller = TextEditingController(text: 'My Character ${custom.length + 1}');
        return AlertDialog(
          title: const Text('Name your character'),
          content: TextField(controller: controller, autofocus: true),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Save')),
          ],
        );
      },
    );
    if (name == null || name.isEmpty) return;
    setState(() => custom.add({'name': name, 'path': image.path, 'type': 'Custom'}));
  }

  @override
  Widget build(BuildContext context) {
    final list = category == 'Custom' ? custom : starter;
    return Scaffold(
      backgroundColor: ink,
      appBar: AppBar(title: const Text('Character Studio')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: gold,
        foregroundColor: ink,
        onPressed: addCharacter,
        icon: const Icon(Icons.add_photo_alternate),
        label: const Text('Add my character'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Wrap(spacing: 8, children: ['Male', 'Female', 'Baby', 'Custom'].map((v) =>
              ChoiceChip(label: Text(v), selected: category == v, onSelected: (_) => setState(() => category = v),
                selectedColor: gold.withOpacity(.25))).toList()),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Row(children: [
              Text(category == 'Custom' ? 'Your characters' : '50 $category character slots',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              const Spacer(),
              Text('${list.length} characters', style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ]),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: list.isEmpty
              ? const Center(child: Text('No custom characters yet. Tap Add my character.'))
              : GridView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                itemCount: list.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.18),
                itemBuilder: (context, i) {
                  final item = list[i];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        if (item['path'] != null)
                          CircleAvatar(radius: 27, backgroundImage: FileImage(File(item['path']!)))
                        else
                          CircleAvatar(radius: 27, backgroundColor: const Color(0xFF2A365B),
                            child: Icon(category == 'Baby' ? Icons.child_care : Icons.person, color: gold, size: 30)),
                        const SizedBox(height: 9),
                        Text(item['name']!, textAlign: TextAlign.center,
                            maxLines: 2, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text(item['type']!, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                      ]),
                    ),
                  );
                },
              ),
          ),
        ],
      ),
    );
  }
}

class CreatePage extends StatefulWidget {
  const CreatePage({super.key});
  @override
  State<CreatePage> createState() => _CreatePageState();
}

class _CreatePageState extends State<CreatePage> {
  final prompt = TextEditingController();
  String mode = 'Text to Video';
  String? selectedFile;
  String message = 'Choose a creation mode to begin.';

  Future<void> chooseFile({bool image = false}) async {
    if (image) {
      final f = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (f != null) setState(() => selectedFile = f.path);
    } else {
      final f = await FilePicker.platform.pickFiles(type: FileType.media);
      if (f != null && f.files.single.path != null) setState(() => selectedFile = f.files.single.path);
    }
  }

  @override
  void dispose() {
    prompt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final modes = ['Text to Video', 'Image to Video', 'Movie to Cartoon', 'Voice Studio', 'Story to Movie'];
    return Scaffold(
      backgroundColor: ink,
      appBar: AppBar(title: const Text('Create with AI')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('What would you like to create?',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          Wrap(spacing: 8, runSpacing: 8, children: modes.map((m) =>
            ChoiceChip(label: Text(m), selected: mode == m,
              onSelected: (_) => setState(() { mode = m; selectedFile = null; message = 'Ready for $m'; }),
              selectedColor: gold.withOpacity(.25))).toList()),
          const SizedBox(height: 18),
          if (mode == 'Image to Video' || mode == 'Movie to Cartoon')
            OutlinedButton.icon(
              onPressed: () => chooseFile(image: mode == 'Image to Video'),
              icon: const Icon(Icons.upload_file),
              label: Text(mode == 'Image to Video' ? 'Choose a picture' : 'Choose a movie file'),
            ),
          if (selectedFile != null)
            Container(margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(12)),
              child: Text('Selected: ${selectedFile!.split('/').last}',
                  maxLines: 2, overflow: TextOverflow.ellipsis)),
          const SizedBox(height: 14),
          TextField(
            controller: prompt,
            minLines: 4,
            maxLines: 7,
            decoration: InputDecoration(
              hintText: mode == 'Voice Studio'
                  ? 'Write the dialogue you want the character to speak...'
                  : 'Describe your story, scene, characters, style and actions...',
              filled: true,
              fillColor: panel,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: const Color(0xFF1B2940), borderRadius: BorderRadius.circular(14)),
            child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.info_outline, color: cyan),
              SizedBox(width: 10),
              Expanded(child: Text(
                'AI generation connection is not configured yet. This starter app saves your project details; a secure AI provider and backend must be connected before real video or voice generation works.',
                style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.4))),
            ]),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: ink, padding: const EdgeInsets.all(15)),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              final entries = prefs.getStringList('projects') ?? [];
              entries.insert(0, jsonEncode({
                'title': mode,
                'prompt': prompt.text.trim(),
                'file': selectedFile,
                'created': DateTime.now().toIso8601String(),
              }));
              await prefs.setStringList('projects', entries);
              if (!mounted) return;
              setState(() => message = 'Project saved. Connect an AI provider to generate the final media.');
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Project saved to My Projects')));
            },
            icon: const Icon(Icons.save_alt),
            label: const Text('Save project'),
          ),
          const SizedBox(height: 12),
          Text(message, style: const TextStyle(color: cyan, fontSize: 12)),
        ],
      ),
    );
  }
}

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key});
  @override
  State<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends State<ProjectsPage> {
  List<Map<String, dynamic>> projects = [];
  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final rows = prefs.getStringList('projects') ?? [];
    setState(() {
      projects = rows.map((e) => Map<String, dynamic>.from(jsonDecode(e))).toList();
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ink,
    appBar: AppBar(title: const Text('My Projects'), actions: [
      IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
    ]),
    body: projects.isEmpty
      ? const Center(child: Text('Your saved projects will appear here.'))
      : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: projects.length,
        itemBuilder: (context, i) {
          final p = projects[i];
          return Card(
            child: ListTile(
              leading: const CircleAvatar(backgroundColor: Color(0xFF29385D), child: Icon(Icons.movie, color: gold)),
              title: Text(p['title'] ?? 'Untitled project'),
              subtitle: Text(p['prompt'] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
              trailing: const Icon(Icons.chevron_right),
            ),
          );
        },
      ),
  );
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool biometric = false;
  String status = 'Device lock is not enabled.';
  final auth = LocalAuthentication();

  Future<void> enableLock() async {
    try {
      final supported = await auth.isDeviceSupported();
      if (!supported) {
        setState(() => status = 'This phone does not support biometric authentication.');
        return;
      }
      final ok = await auth.authenticate(
        localizedReason: 'Confirm it is you to protect Salman Studio',
        options: const AuthenticationOptions(biometricOnly: false, stickyAuth: true),
      );
      setState(() {
        biometric = ok;
        status = ok ? 'Authentication confirmed on this device.' : 'Authentication was not completed.';
      });
    } catch (e) {
      setState(() => status = 'Device authentication is unavailable: $e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ink,
    appBar: AppBar(title: const Text('Settings & Privacy')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const BrandMark(size: 72),
      const SizedBox(height: 14),
      const Text('SALMAN STUDIO', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
      const Text('Personal AI Cartoon & Movie Studio', style: TextStyle(color: Colors.white54)),
      const SizedBox(height: 24),
      Card(child: SwitchListTile(
        value: biometric,
        onChanged: (_) => enableLock(),
        secondary: const Icon(Icons.fingerprint, color: gold),
        title: const Text('Device authentication'),
        subtitle: Text(status),
      )),
      const Card(child: ListTile(
        leading: Icon(Icons.privacy_tip, color: cyan),
        title: Text('Private project storage'),
        subtitle: Text('Projects are currently stored locally on this device.'),
      )),
      const Card(child: ListTile(
        leading: Icon(Icons.cloud_outlined, color: cyan),
        title: Text('AI services'),
        subtitle: Text('A secure backend and provider credentials are required for cloud AI generation.'),
      )),
      const Card(child: ListTile(
        leading: Icon(Icons.info_outline, color: cyan),
        title: Text('App version'),
        subtitle: Text('Salman Studio 1.0.0 - Starter build'),
      )),
    ]),
  );
}
