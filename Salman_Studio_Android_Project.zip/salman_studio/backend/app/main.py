from __future__ import annotations

import os
import secrets
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    access_token: str = Field(default="", alias="SALMAN_STUDIO_ACCESS_TOKEN")
    upload_dir: str = Field(default="./uploads", alias="UPLOAD_DIR")

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
app = FastAPI(title="Salman Studio API", version="0.1.0")
JOBS: dict[str, dict] = {}


def require_device_token(x_studio_token: str | None = Header(default=None)):
    """Starter access gate. Replace with proper user/device auth before public deployment."""
    if not settings.access_token:
        raise HTTPException(status_code=503, detail="Server access token is not configured")
    if not x_studio_token or not secrets.compare_digest(x_studio_token, settings.access_token):
        raise HTTPException(status_code=401, detail="This device is not authorized")
    return True


class JobRequest(BaseModel):
    kind: Literal["text_to_video", "image_to_video", "movie_to_cartoon", "story_to_movie", "voice"]
    prompt: str = Field(default="", max_length=12000)
    asset_ids: list[str] = Field(default_factory=list, max_length=100)
    style: str = Field(default="3D cartoon", max_length=100)
    language: str = Field(default="ur", max_length=20)


@app.get("/health")
def health():
    return {"ok": True, "service": "Salman Studio API", "time": datetime.now(timezone.utc).isoformat()}


@app.post("/v1/assets", dependencies=[Depends(require_device_token)])
async def upload_asset(file: UploadFile = File(...)):
    allowed = {"image/jpeg", "image/png", "image/webp", "video/mp4", "video/quicktime", "audio/mpeg", "audio/wav", "audio/mp4"}
    if file.content_type not in allowed:
        raise HTTPException(status_code=415, detail="Unsupported file type")
    root = Path(settings.upload_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    suffix = Path(file.filename or "upload.bin").suffix[:12]
    asset_id = uuid.uuid4().hex
    target = root / f"{asset_id}{suffix}"
    total = 0
    limit = 2 * 1024 * 1024 * 1024  # 2 GB starter cap; configure storage for production.
    try:
        with target.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                total += len(chunk)
                if total > limit:
                    out.close()
                    target.unlink(missing_ok=True)
                    raise HTTPException(status_code=413, detail="File exceeds starter 2 GB limit")
                out.write(chunk)
    finally:
        await file.close()
    return {"asset_id": asset_id, "filename": file.filename, "bytes": total, "status": "uploaded"}


@app.post("/v1/jobs", dependencies=[Depends(require_device_token)])
def create_job(body: JobRequest):
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {
        "job_id": job_id,
        "kind": body.kind,
        "prompt": body.prompt,
        "asset_ids": body.asset_ids,
        "style": body.style,
        "language": body.language,
        "status": "awaiting_provider_configuration",
        "message": "Connect a licensed AI provider and background worker to run this job.",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    return JOBS[job_id]


@app.get("/v1/jobs/{job_id}", dependencies=[Depends(require_device_token)])
def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@app.get("/v1/providers", dependencies=[Depends(require_device_token)])
def providers():
    return {
        "video": bool(os.getenv("VIDEO_PROVIDER_API_KEY")),
        "image": bool(os.getenv("IMAGE_PROVIDER_API_KEY")),
        "voice": bool(os.getenv("VOICE_PROVIDER_API_KEY")),
        "note": "Provider adapters are not implemented in this starter package."
    }
