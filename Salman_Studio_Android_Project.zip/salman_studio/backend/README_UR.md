# Backend starter (اردو)

یہ FastAPI کا ابتدائی سرور ہے۔ اسے کمپیوٹر یا cloud server پر چلایا جاتا ہے؛ Android فون پر ہی مکمل AI ویڈیو جنریشن مقامی طور پر چلنے کا دعویٰ نہیں کرتا۔

- `/health`: سرور چیک
- `/v1/assets`: نجی ٹوکن کے ساتھ تصویر/ویڈیو/آڈیو اپلوڈ
- `/v1/jobs`: جنریشن جاب بنانا
- `/v1/jobs/{job_id}`: جاب کی حالت دیکھنا
- `/v1/providers`: کن API keys کی موجودگی چیک کرنا

چلانے کے لیے:
1. `.env.example` کی کاپی `.env` بنائیں اور ایک لمبا random access token دیں۔
2. `pip install -r requirements.txt`
3. `uvicorn app.main:app --host 0.0.0.0 --port 8000`

اہم: AI provider adapters، background worker، production authentication اور private cloud storage ابھی شامل نہیں۔ API keys کبھی Flutter app میں نہ رکھیں۔
